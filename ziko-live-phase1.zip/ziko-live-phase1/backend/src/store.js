import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const dataPath = path.resolve(here, '../data/dev-db.json');
const blank = () => ({ users: [], sessions: [] });

class JsonStore {
  async init() {
    await fs.mkdir(path.dirname(dataPath), { recursive: true });
    try { JSON.parse(await fs.readFile(dataPath, 'utf8')); }
    catch { await fs.writeFile(dataPath, JSON.stringify(blank(), null, 2)); }
  }
  async read() { await this.init(); return JSON.parse(await fs.readFile(dataPath, 'utf8')); }
  async write(db) { await fs.writeFile(dataPath, JSON.stringify(db, null, 2)); }
  async findUserByEmail(email) { return (await this.read()).users.find(u => u.email === email) || null; }
  async findUserById(id) { return (await this.read()).users.find(u => u.id === id) || null; }
  async listUsers() { return (await this.read()).users.map(publicUser); }
  async createUser(user) {
    const db = await this.read();
    if (db.users.some(u => u.email === user.email)) throw Object.assign(new Error('Email already registered'), { status: 409 });
    db.users.push(user); await this.write(db); return user;
  }
  async updateUser(id, patch) {
    const db = await this.read(); const i = db.users.findIndex(u => u.id === id);
    if (i < 0) return null;
    db.users[i] = { ...db.users[i], ...patch, updatedAt: new Date().toISOString() };
    await this.write(db); return db.users[i];
  }
  async saveSession(session) { const db = await this.read(); db.sessions = db.sessions.filter(s => s.tokenId !== session.tokenId); db.sessions.push(session); await this.write(db); }
  async removeSession(tokenId) { const db = await this.read(); db.sessions = db.sessions.filter(s => s.tokenId !== tokenId); await this.write(db); }
  async sessionExists(tokenId) { return (await this.read()).sessions.some(s => s.tokenId === tokenId); }
  async ownerExists() { return (await this.read()).users.some(u => u.role === 'owner'); }
}

class PgStore {
  constructor(pool) { this.pool = pool; }
  async init() { await this.pool.query('SELECT 1'); }
  async findUserByEmail(email) { const r = await this.pool.query('SELECT * FROM users WHERE email=$1', [email]); return mapPgUser(r.rows[0]); }
  async findUserById(id) { const r = await this.pool.query('SELECT * FROM users WHERE id=$1', [id]); return mapPgUser(r.rows[0]); }
  async listUsers() { const r = await this.pool.query('SELECT id,email,display_name AS "displayName",role,status,country,language,bio,created_at AS "createdAt",updated_at AS "updatedAt" FROM users ORDER BY created_at DESC LIMIT 500'); return r.rows; }
  async createUser(u) {
    try {
      const r = await this.pool.query(`INSERT INTO users(id,email,password_hash,display_name,role,status,country,language,bio,created_at,updated_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [u.id,u.email,u.passwordHash,u.displayName,u.role,u.status,u.country,u.language,u.bio,u.createdAt,u.updatedAt]);
      return mapPgUser(r.rows[0]);
    } catch (e) { if (e.code === '23505') throw Object.assign(new Error('Email already registered'), { status: 409 }); throw e; }
  }
  async updateUser(id, p) {
    const current = await this.findUserById(id); if (!current) return null;
    const merged = { ...mapPgUser(current), ...p, updatedAt: new Date().toISOString() };
    const r = await this.pool.query(`UPDATE users SET display_name=$2,country=$3,language=$4,bio=$5,status=$6,updated_at=$7 WHERE id=$1 RETURNING *`,
      [id,merged.displayName,merged.country,merged.language,merged.bio,merged.status,merged.updatedAt]);
    return mapPgUser(r.rows[0]);
  }
  async saveSession(s) { await this.pool.query(`INSERT INTO sessions(token_id,user_id,expires_at,created_at) VALUES($1,$2,$3,$4) ON CONFLICT(token_id) DO NOTHING`, [s.tokenId,s.userId,s.expiresAt,s.createdAt]); }
  async removeSession(id) { await this.pool.query('DELETE FROM sessions WHERE token_id=$1',[id]); }
  async sessionExists(id) { const r = await this.pool.query('SELECT 1 FROM sessions WHERE token_id=$1 AND expires_at>now()', [id]); return r.rowCount > 0; }
  async ownerExists() { const r = await this.pool.query("SELECT 1 FROM users WHERE role='owner' LIMIT 1"); return r.rowCount > 0; }
}
function mapPgUser(u) {
  if (!u) return null;
  return { id:u.id,email:u.email,passwordHash:u.password_hash,displayName:u.display_name,role:u.role,status:u.status,country:u.country,language:u.language,bio:u.bio,createdAt:new Date(u.created_at).toISOString(),updatedAt:new Date(u.updated_at).toISOString() };
}
export function publicUser(u) {
  if (!u) return null;
  const { passwordHash, password_hash, ...rest } = u;
  return rest;
}
export async function createStore() {
  if (process.env.DATABASE_URL) {
    const { Pool } = await import('pg');
    const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSLMODE === 'require' ? { rejectUnauthorized: true } : undefined });
    const store = new PgStore(pool); await store.init(); return store;
  }
  if (process.env.NODE_ENV === 'production' || process.env.DEV_JSON_DB === 'false') {
    throw new Error('DATABASE_URL is required outside development; refusing to start with JSON storage.');
  }
  const store = new JsonStore(); await store.init(); return store;
}
