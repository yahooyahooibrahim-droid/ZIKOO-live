import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { hashPassword, verifyPassword, signToken, verifyToken } from './security.js';
import { createStore, publicUser } from './store.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// Minimal .env loader keeps the development setup dependency-free. Existing process variables win.
try {
  const envText = await fs.readFile(path.resolve(__dirname, '../.env'), 'utf8');
  for (const line of envText.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
} catch {}
const root = path.resolve(__dirname, '../../');
const PORT = Number(process.env.PORT || 8080);
const JWT_SECRET = process.env.JWT_SECRET || (process.env.NODE_ENV === 'production' ? '' : 'dev-only-secret-change-this-before-deploy-123456789');
if (!JWT_SECRET || JWT_SECRET.length < 32) throw new Error('JWT_SECRET must be at least 32 characters.');
const allowedOrigin = process.env.CORS_ORIGIN || 'http://localhost:8080';
const store = await createStore();
const attempts = new Map();

function json(res, status, data) {
  res.writeHead(status, { 'content-type':'application/json; charset=utf-8', 'cache-control':'no-store',
    'x-content-type-options':'nosniff', 'x-frame-options':'DENY', 'referrer-policy':'no-referrer' });
  res.end(JSON.stringify(data));
}
function cors(req, res) {
  const origin = req.headers.origin;
  if (origin && (origin === allowedOrigin || (process.env.NODE_ENV !== 'production' && origin.startsWith('http://localhost:')))) {
    res.setHeader('access-control-allow-origin', origin);
    res.setHeader('vary', 'Origin');
  }
  res.setHeader('access-control-allow-headers','content-type,authorization,x-owner-bootstrap-secret');
  res.setHeader('access-control-allow-methods','GET,POST,PATCH,OPTIONS');
}
async function body(req) {
  let raw = ''; for await (const chunk of req) { raw += chunk; if (raw.length > 1_000_000) throw Object.assign(new Error('Request too large'), {status:413}); }
  if (!raw) return {};
  try { return JSON.parse(raw); } catch { throw Object.assign(new Error('Invalid JSON'), {status:400}); }
}
function rateLimit(key, limit=12, windowMs=60_000) {
  const now = Date.now(); const old = attempts.get(key) || [];
  const active = old.filter(t => now-t < windowMs); active.push(now); attempts.set(key,active);
  return active.length <= limit;
}
function emailValid(email) { return typeof email === 'string' && email.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email); }
function safeString(v, max) { return typeof v === 'string' ? v.trim().slice(0,max) : ''; }
async function auth(req) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i,'');
  const p = verifyToken(token, JWT_SECRET);
  if (!p || !(await store.sessionExists(p.jti))) return null;
  const user = await store.findUserById(p.sub);
  if (!user || user.status !== 'active') return null;
  return { user, token: p };
}
function adminOnly(ctx) { return ctx && ['owner','super_admin','admin'].includes(ctx.user.role); }
async function serveStatic(res, file, type) {
  try { const data = await fs.readFile(path.join(root, file)); res.writeHead(200, {'content-type':type,'cache-control':'no-store','x-content-type-options':'nosniff','x-frame-options':'DENY'}); res.end(data); }
  catch { json(res,404,{error:'Not found'}); }
}
const server = http.createServer(async (req,res) => {
  cors(req,res);
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const ip = req.socket.remoteAddress || 'unknown';
  try {
    if (req.method === 'GET' && url.pathname === '/health') return json(res,200,{status:'ok',service:'ziko-live-api',timestamp:new Date().toISOString(),storage:process.env.DATABASE_URL?'postgresql':'development-json'});
    if (req.method === 'GET' && url.pathname === '/admin/') return serveStatic(res,'admin/index.html','text/html; charset=utf-8');
    if (req.method === 'GET' && url.pathname.startsWith('/admin/')) {
      const asset = url.pathname.slice(1);
      const types = {'.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml'};
      return serveStatic(res,asset,types[path.extname(asset)] || 'application/octet-stream');
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/auth/register') {
      if (!rateLimit(`register:${ip}`,8)) return json(res,429,{error:'Too many attempts. Try again later.'});
      const b = await body(req); const email = safeString(b.email,254).toLowerCase(); const password = b.password;
      if (!emailValid(email)) return json(res,400,{error:'Enter a valid email address.'});
      if (typeof password !== 'string' || password.length < 10 || password.length > 128) return json(res,400,{error:'Password must be 10–128 characters.'});
      const now = new Date().toISOString();
      const user = { id:crypto.randomUUID(), email, passwordHash:await hashPassword(password), displayName:safeString(b.displayName,40) || email.split('@')[0], role:'user', status:'active', country:safeString(b.country,2).toUpperCase(), language:'ar', bio:'', createdAt:now, updatedAt:now };
      await store.createUser(user);
      return json(res,201,{user:publicUser(user)});
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/auth/login') {
      if (!rateLimit(`login:${ip}`,10)) return json(res,429,{error:'Too many login attempts. Try again later.'});
      const b = await body(req); const email = safeString(b.email,254).toLowerCase();
      const user = await store.findUserByEmail(email);
      if (!user || !(await verifyPassword(String(b.password || ''),user.passwordHash || user.password_hash || ''))) return json(res,401,{error:'Invalid email or password.'});
      if (user.status !== 'active') return json(res,403,{error:'Account is not active.'});
      const jti = crypto.randomUUID(); const now = new Date();
      const token = signToken({sub:user.id,jti,role:user.role},JWT_SECRET);
      await store.saveSession({tokenId:jti,userId:user.id,createdAt:now.toISOString(),expiresAt:new Date(now.getTime()+7*86400_000).toISOString()});
      return json(res,200,{token,expiresIn:604800,user:publicUser(user)});
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/auth/logout') {
      const ctx = await auth(req); if (!ctx) return json(res,401,{error:'Authentication required.'});
      await store.removeSession(ctx.token.jti); return json(res,200,{ok:true});
    }
    if (req.method === 'GET' && url.pathname === '/api/v1/me') {
      const ctx = await auth(req); if (!ctx) return json(res,401,{error:'Authentication required.'});
      return json(res,200,{user:publicUser(ctx.user)});
    }
    if (req.method === 'PATCH' && url.pathname === '/api/v1/me') {
      const ctx = await auth(req); if (!ctx) return json(res,401,{error:'Authentication required.'});
      const b = await body(req); const patch = {};
      if (b.displayName !== undefined) { if (typeof b.displayName !== 'string' || b.displayName.trim().length < 2) return json(res,400,{error:'Display name must contain at least 2 characters.'}); patch.displayName=safeString(b.displayName,40); }
      if (b.bio !== undefined) patch.bio=safeString(b.bio,180);
      if (b.country !== undefined) patch.country=safeString(b.country,2).toUpperCase();
      if (b.language !== undefined && ['ar','en'].includes(b.language)) patch.language=b.language;
      const updated = await store.updateUser(ctx.user.id,patch);
      return json(res,200,{user:publicUser(updated)});
    }
    if (req.method === 'POST' && url.pathname === '/api/v1/setup/owner') {
      const secret = process.env.OWNER_BOOTSTRAP_SECRET || '';
      if (!secret || secret.length < 24 || req.headers['x-owner-bootstrap-secret'] !== secret) return json(res,403,{error:'Owner bootstrap is not configured or secret is invalid.'});
      if (await store.ownerExists()) return json(res,409,{error:'An owner already exists.'});
      const b = await body(req); const email = safeString(b.email,254).toLowerCase();
      if (!emailValid(email) || (process.env.OWNER_EMAIL && email !== process.env.OWNER_EMAIL.toLowerCase())) return json(res,400,{error:'Email does not match OWNER_EMAIL.'});
      if (typeof b.password !== 'string' || b.password.length < 14 || b.password.length > 128) return json(res,400,{error:'Owner password must be 14–128 characters.'});
      const now = new Date().toISOString();
      const user = {id:crypto.randomUUID(),email,passwordHash:await hashPassword(b.password),displayName:safeString(b.displayName,40)||'ZIKO Owner',role:'owner',status:'active',country:'EG',language:'ar',bio:'',createdAt:now,updatedAt:now};
      await store.createUser(user);
      return json(res,201,{user:publicUser(user),message:'Owner created. Remove/rotate the bootstrap secret now.'});
    }
    if (req.method === 'GET' && url.pathname === '/api/v1/admin/users') {
      const ctx = await auth(req); if (!adminOnly(ctx)) return json(res,403,{error:'Administrator permission required.'});
      return json(res,200,{users:await store.listUsers()});
    }
    if (req.method === 'GET' && url.pathname === '/api/v1/admin/summary') {
      const ctx = await auth(req); if (!adminOnly(ctx)) return json(res,403,{error:'Administrator permission required.'});
      const users = await store.listUsers();
      return json(res,200,{users:users.length,active:users.filter(u=>u.status==='active').length,roles:{owner:users.filter(u=>u.role==='owner').length,admins:users.filter(u=>['admin','super_admin'].includes(u.role)).length},phase:'Phase 1 foundation'});
    }
    return json(res,404,{error:'Route not found.'});
  } catch (e) {
    const status = e.status || 500;
    if (status >= 500) console.error(new Date().toISOString(), e);
    return json(res,status,{error:status===500?'Internal server error.':e.message});
  }
});
server.listen(PORT,'0.0.0.0',()=>console.log(`ZIKO LIVE API listening on http://localhost:${PORT}`));
