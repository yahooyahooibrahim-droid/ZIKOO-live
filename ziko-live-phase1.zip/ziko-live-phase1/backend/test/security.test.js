import test from 'node:test';
import assert from 'node:assert/strict';
import { hashPassword, verifyPassword, signToken, verifyToken } from '../src/security.js';

test('password hash verifies only correct password', async () => {
  const hash = await hashPassword('a-strong-password-123');
  assert.notEqual(hash, 'a-strong-password-123');
  assert.equal(await verifyPassword('a-strong-password-123', hash), true);
  assert.equal(await verifyPassword('wrong-password', hash), false);
});

test('signed tokens validate signature and expiry', () => {
  const secret = 'unit-test-secret-with-enough-length-123456';
  const token = signToken({sub:'user-1',jti:'session-1'}, secret, 60);
  assert.equal(verifyToken(token, secret).sub, 'user-1');
  assert.equal(verifyToken(token, 'a-different-secret-that-is-also-long'), null);
  assert.equal(verifyToken('invalid', secret), null);
});
