CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY,
  email VARCHAR(254) NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name VARCHAR(40) NOT NULL,
  role VARCHAR(24) NOT NULL DEFAULT 'user' CHECK (role IN ('user','host','agent','agency_manager','moderator','admin','super_admin','owner')),
  status VARCHAR(24) NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','banned','pending_deletion')),
  country CHAR(2) NOT NULL DEFAULT '',
  language VARCHAR(8) NOT NULL DEFAULT 'ar' CHECK (language IN ('ar','en')),
  bio VARCHAR(180) NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS users_created_at_idx ON users(created_at DESC);
CREATE TABLE IF NOT EXISTS sessions (
  token_id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions(user_id);
CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions(expires_at);
