# ZIKO LIVE — Phase 1 foundation

This repository contains a runnable Phase 1 foundation for the ZIKO LIVE Android app + web owner dashboard.

## What is included
- Node.js API using built-in HTTP modules (no framework dependency).
- Registration, login, logout, session validation, profile retrieval/update.
- Password hashing with scrypt, signed bearer tokens, input validation, basic rate limiting.
- Role-based admin endpoints; the first owner is bootstrapped only from server environment variables.
- Persistent local JSON storage for development; optional PostgreSQL adapter when `DATABASE_URL` is set.
- PostgreSQL schema/migration SQL.
- Arabic-first RTL web admin dashboard served by the API.
- Flutter client source for Android with RTL login/register/home/profile foundation.
- Automated Node tests for password hashing, token verification, and API behavior.

## Requirements
- Node.js 20+.
- Optional PostgreSQL 15+ for database-backed operation.
- Flutter SDK 3.24+ for building the Android client.
- Docker is optional; a compose file is included for PostgreSQL only.

## Run the API + admin dashboard (local development)
```bash
cd backend
cp .env.example .env
npm test
npm start
```
Open `http://localhost:8080/admin/`.

The local JSON database is written to `backend/data/dev-db.json`. It is intended for development only. Do not use it for production or multiple server instances.

## Run with PostgreSQL
1. Start PostgreSQL (or use your managed PostgreSQL service).
2. Create a database and set `DATABASE_URL` in `backend/.env`.
3. Apply `backend/migrations/001_init.sql` to that database.
4. Set a strong `JWT_SECRET` and a strong `OWNER_BOOTSTRAP_SECRET`.
5. Run `npm install` and `npm start`.

When `DATABASE_URL` is set, the server loads the `pg` package and uses PostgreSQL. `pg` is declared in `package.json`.

## Bootstrap the owner
Set `OWNER_EMAIL` and `OWNER_BOOTSTRAP_SECRET` before the first run. To bootstrap, send:
```bash
curl -X POST http://localhost:8080/api/v1/setup/owner \
  -H 'content-type: application/json' \
  -H 'x-owner-bootstrap-secret: YOUR_BOOTSTRAP_SECRET' \
  -d '{"email":"owner@example.com","password":"A-long-unique-password","displayName":"ZIKO Owner"}'
```
The endpoint only creates an owner when no owner exists. Remove/rotate the bootstrap secret after setup. Never expose it in the Android app or browser code.

## Flutter Android client
```bash
cd android_app
flutter pub get
flutter run
```
For a physical phone, set `API_BASE_URL` in `lib/config.dart` to your computer's LAN IP, for example `http://192.168.1.20:8080`. For Android emulator, use `http://10.0.2.2:8080`. For production, use HTTPS.

## Current implementation status
**Implemented in source:** local account registration/login/logout, profile read/update, signed tokens, password hashing, persisted sessions, owner bootstrap guard, admin user listing, role checks, health endpoint, PostgreSQL schema/adapter, Arabic RTL dashboard foundation, Flutter client foundation.

**Not implemented yet:** SMS/OTP delivery, Google/Facebook provider login, live audio rooms/Agora, gifts and animations as live events, coin purchase/payment callbacks, financial ledger and withdrawals, agency/target systems, push notifications, moderation workflows beyond basic user status, production deployment/monitoring. Those belong to later phases or require credentials/provider approval.

**Verification performed:** `npm test` and local API smoke tests are expected to run using Node.js. Flutter compilation has not been verified unless run on a machine with Flutter installed. No live PostgreSQL test is claimed in this environment.

## Security notes
- Set a unique 32+ character `JWT_SECRET` for deployment.
- Use HTTPS behind a properly configured reverse proxy.
- Restrict CORS to your actual origins before deployment.
- Development JSON storage is not suitable for production.
- Do not treat the demo owner bootstrap secret as an ongoing login mechanism.
