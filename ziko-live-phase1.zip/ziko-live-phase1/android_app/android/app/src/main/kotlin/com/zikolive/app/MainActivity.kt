package com.zikolive.app
import io.flutter.embedding.android.FlutterActivity
class MainActivity : FlutterActivity()
