import 'package:flutter_test/flutter_test.dart';
import 'package:ziko_live/main.dart';

void main() {
  test('application class can be constructed', () {
    const app = ZikoLiveApp();
    expect(app, isNotNull);
  });
}
