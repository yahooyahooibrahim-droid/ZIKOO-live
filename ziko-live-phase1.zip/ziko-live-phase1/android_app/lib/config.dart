class AppConfig {
  // Android emulator: http://10.0.2.2:8080
  // Physical device: use your computer's LAN IP, and HTTPS in production.
  static const apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8080/api/v1',
  );
}
