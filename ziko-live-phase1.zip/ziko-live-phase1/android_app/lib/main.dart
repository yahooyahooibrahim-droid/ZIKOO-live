import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'config.dart';

void main() => runApp(const ZikoLiveApp());

const gold = Color(0xFFF5C15B);
const bg = Color(0xFF06070B);
const panel = Color(0xFF12131B);
const purple = Color(0xFF7D3CFF);

class ZikoLiveApp extends StatelessWidget {
  const ZikoLiveApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'ZIKO LIVE', debugShowCheckedModeBanner: false,
    theme: ThemeData.dark().copyWith(scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: panel,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFF55401F))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFF55401F))))),
    home: const Directionality(textDirection: TextDirection.rtl, child: AuthGate()),
  );
}

class Api {
  static Future<Map<String,dynamic>> post(String path, Map<String,dynamic> data) async {
    final r = await http.post(Uri.parse('${AppConfig.apiBaseUrl}$path'), headers: {'content-type':'application/json'}, body: jsonEncode(data)).timeout(const Duration(seconds: 12));
    final d = jsonDecode(r.body) as Map<String,dynamic>;
    if (r.statusCode >= 400) throw Exception(d['error'] ?? 'حدث خطأ');
    return d;
  }
  static Future<Map<String,dynamic>> getMe(String token) async {
    final r = await http.get(Uri.parse('${AppConfig.apiBaseUrl}/me'),headers:{'authorization':'Bearer $token'}).timeout(const Duration(seconds:12));
    final d = jsonDecode(r.body) as Map<String,dynamic>;
    if(r.statusCode>=400) throw Exception(d['error']??'تعذر تحميل الحساب');
    return d['user'] as Map<String,dynamic>;
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override State<AuthGate> createState()=>_AuthGateState();
}
class _AuthGateState extends State<AuthGate> {
  String? token; Map<String,dynamic>? user; bool loading=true;
  @override void initState(){super.initState();_restore();}
  Future<void> _restore() async {
    final p=await SharedPreferences.getInstance(); final t=p.getString('token');
    if(t!=null){try{user=await Api.getMe(t);token=t;}catch{await p.remove('token');}}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> onLogin(String t,Map<String,dynamic> u) async {final p=await SharedPreferences.getInstance();await p.setString('token',t);setState(()=>{token=t,user=u});}
  Future<void> onLogout() async {final p=await SharedPreferences.getInstance();await p.remove('token');setState(()=>{token=null,user=null});}
  @override Widget build(BuildContext context)=>loading?const Scaffold(body:Center(child:CircularProgressIndicator(color:gold))):token==null?LoginScreen(onLogin:onLogin):HomeScreen(user:user!,token:token!,onLogout:onLogout);
}

class LoginScreen extends StatefulWidget {
  final Future<void> Function(String,Map<String,dynamic>) onLogin;
  const LoginScreen({super.key,required this.onLogin});
  @override State<LoginScreen> createState()=>_LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen>{
  final email=TextEditingController(),password=TextEditingController(),name=TextEditingController();
  bool register=false,busy=false;String error='';
  Future<void> submit() async {setState(()=>{busy=true,error=''});try{
    final d=await Api.post(register?'/auth/register':'/auth/login',{'email':email.text.trim(),'password':password.text,'displayName':name.text.trim()});
    if(register){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم إنشاء الحساب. سجّل الدخول الآن.')));setState(()=>register=false);}
    else await widget.onLogin(d['token'] as String,Map<String,dynamic>.from(d['user'] as Map));
  }catch(e){setState(()=>error=e.toString().replaceFirst('Exception: ','').replaceAll('Exception: ',''));}finally{if(mounted)setState(()=>busy=false);}}
  @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:440),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    const SizedBox(height:20),Container(height:100,width:100,alignment:Alignment.center,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:gold,width:2),boxShadow:[BoxShadow(color:gold.withOpacity(.18),blurRadius:30)]),child:const Text('Z',style:TextStyle(color:gold,fontSize:70,fontWeight:FontWeight.w900))),
    const SizedBox(height:16),const Text('ZIKO LIVE',textAlign:TextAlign.center,style:TextStyle(fontSize:32,color:gold,fontWeight:FontWeight.w900)),const Text('دردشة صوتية · أصدقاء · متعة',textAlign:TextAlign.center,style:TextStyle(color:Colors.white70)),const SizedBox(height:30),
    if(register)TextField(controller:name,decoration:const InputDecoration(labelText:'الاسم الظاهر')),
    const SizedBox(height:12),TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'البريد الإلكتروني')),
    const SizedBox(height:12),TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'كلمة المرور')),
    if(error.isNotEmpty)Padding(padding:const EdgeInsets.only(top:12),child:Text(error,style:const TextStyle(color:Colors.redAccent))),
    const SizedBox(height:20),ElevatedButton(onPressed:busy?null:submit,style:ElevatedButton.styleFrom(backgroundColor:gold,foregroundColor:Colors.black,padding:const EdgeInsets.all(16)),child:Text(busy?'جارٍ التنفيذ…':register?'إنشاء حساب':'تسجيل الدخول')),
    TextButton(onPressed:busy?null:()=>setState(()=>{register=!register,error=''}),child:Text(register?'لديك حساب بالفعل؟ سجّل الدخول':'إنشاء حساب جديد',style:const TextStyle(color:gold))),
    const SizedBox(height:18),const Text('المرحلة الأولى: تسجيل الحساب والملف الشخصي. تسجيل OTP والغرف الصوتية غير مفعّلين بعد.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white38,fontSize:12))
  ]))))));
}

class HomeScreen extends StatelessWidget {
  final Map<String,dynamic> user; final String token; final Future<void> Function() onLogout;
  const HomeScreen({super.key,required this.user,required this.token,required this.onLogout});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('ZIKO LIVE',style:TextStyle(color:gold,fontWeight:FontWeight.bold)),actions:[IconButton(onPressed:onLogout,icon:const Icon(Icons.logout))]),body:ListView(padding:const EdgeInsets.all(18),children:[
    Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(borderRadius:BorderRadius.circular(22),gradient:const LinearGradient(colors:[Color(0xFF25133C),Color(0xFF12131B)]),border:Border.all(color:gold.withOpacity(.7))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('أهلاً بيك في ZIKO LIVE',style:TextStyle(fontSize:23,color:gold,fontWeight:FontWeight.bold)),const SizedBox(height:8),Text(user['displayName']??'مستخدم'),Text(user['email']??'',style:const TextStyle(color:Colors.white60)),const SizedBox(height:10),const Text('عالم من الدردشة والصداقة يبدأ هنا',style:TextStyle(color:Colors.white70))]),
    const SizedBox(height:18),_feature(Icons.groups_rounded,'الغرف الصوتية','ستُفعّل في المرحلة الثانية'),_feature(Icons.card_giftcard,'متجر الهدايا','سيُفعّل بعد بناء نظام الهدايا'),_feature(Icons.account_balance_wallet,'المحفظة والكوينز','المعاملات المالية غير مفعّلة بعد'),_feature(Icons.verified_user,'الحساب والصلاحيات','تم تسجيل الدخول من خلال واجهة API'),const SizedBox(height:12),const Text('مهم: هذه الشاشة لا تحاكي اتصالًا صوتيًا أو مدفوعات. المزايا غير الجاهزة موضّحة بوضوح.',style:TextStyle(color:Colors.white38,fontSize:12))
  ]));
  Widget _feature(IconData icon,String title,String sub)=>Container(margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16),border:Border.all(color:const Color(0xFF45331B))),child:Row(children:[Icon(icon,color:gold,size:30),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:4),Text(sub,style:const TextStyle(color:Colors.white54,fontSize:12))]))]));
}
